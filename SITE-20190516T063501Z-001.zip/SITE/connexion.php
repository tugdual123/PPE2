<?php
	
	if($_POST['pseudo'] != "")
	{
		if ($_POST['password'] != "")
		{
			$pseudo = $_POST["pseudo"];
			$password = $_POST["password"];

			include("connexionbdd.php");

			$requete = $connexion->query("SELECT * FROM professeur WHERE pseudo_professeur = '$pseudo'");
			$ligne = $requete->fetch();
			if ($ligne['pseudo_professeur'] != "")
			{
			
				if ($ligne['mdp_professeur'] == $password) {
					
					session_start ();
					$_SESSION['type'] = "professeur";
					$_SESSION['pseudo_professeur'] = $pseudo;
					$_SESSION['mdp_professeur'] = $password;

					echo '<body onLoad="alert(\'Vous êtes connecté en tant que professeur !\')">';
					echo '<meta http-equiv="refresh" content="0;URL=formPB.html">';
				}
				else {
					echo '<body onLoad="alert(\'Mauvais pseudo ou mot de passe. Veuillez recommencer\')">';
					echo '<meta http-equiv="refresh" content="0;URL=connexion.html">';
				}
			}
			else {
				
				$requete2 = $connexion->query("SELECT * FROM technicien WHERE pseudo_technicien = '$pseudo'");
				$ligne2 = $requete2->fetch();
				
				if ($ligne2['mdp_technicien'] == $password) {
					
					session_start ();
					$_SESSION['type'] = "technicien";
					$_SESSION['pseudo_technicien'] = $pseudo;
					$_SESSION['mdp_technicien'] = $password;

					echo '<body onLoad="alert(\'Vous êtes connecté en tant que technicien !\')">';
					echo '<meta http-equiv="refresh" content="0;URL=voirprobleme.php">';
				}
				else {
					echo '<body onLoad="alert(\'Mauvais pseudo ou mot de passe. Veuillez recommencer\')">';
					echo '<meta http-equiv="refresh" content="0;URL=connexion.html">';
				}
			}
			
		}
		else {
			echo '<body onLoad="alert(\'Vous navez pas remplie tout les champs. Veuillez recommencer\')">';
			echo '<meta http-equiv="refresh" content="0;URL=connexion.html">';
		}
	}
	else {
		echo '<body onLoad="alert(\'Vous navez pas remplie tout les champs. Veuillez recommencer\')">';
		echo '<meta http-equiv="refresh" content="0;URL=connexion.html">';
	}
?>
