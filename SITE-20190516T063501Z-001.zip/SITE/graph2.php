<?php
include ("/jpgraph/src/jpgraph.php");
include ("/jpgraph/src/jpgraph_bar.php");
include ("connexionbdd.php");

//supprimé le fichiers "graph1.png" avant d'en créer un nouveau 
unlink("graph2.png");

$tableauMois = array();
$tableauNombreProbleme = array();


// **********************************************
// Extraction des données dans la base de données
// *************************************************

//requête 
$requete = $connexion->query("SELECT extract(month from date) AS MOIS, COUNT(*) AS NBR
FROM probleme
WHERE extract(year from date) = 2019
GROUP BY extract(month from date)
");
// Fetch sur chaque enregistrement
while ($row = $requete->fetch()) {
	// Alimentation des tableaux de données
	$tableauNombreProbleme[] = $row['NBR'];
	$tableauMois[] = $row['MOIS'];
}


//printf('<pre>%s</pre>', print_r($tableauAnnees,1));
//printf('<pre>%s</pre>', print_r($tableauNombreProbleme,1));


// *******************
// Création du graphique
// *******************

// Create the graph and setup the basic parameters
$graph = new Graph(1000,600,'auto');
$graph->clearTheme();
$graph->img->SetMargin(40,30,30,40);
$graph->SetScale("textint");
$graph->SetShadow();
$graph->SetFrame(false); // No border around the graph

// Add some grace to the top so that the scale doesn't
// end exactly at the max value.
$graph->yaxis->scale->SetGrace(100);

// Setup X-axis labels
//$a = $gDateLocale->GetMonth();
$graph->xaxis->SetTickLabels($tableauMois);
$graph->xaxis->SetFont(FF_FONT2);

// Setup graph title ands fonts
$graph->title->Set("Nombre de probleme par mois");
$graph->title->SetFont(FF_FONT2,FS_BOLD);
$graph->xaxis->title->Set("Annee 2019");
$graph->xaxis->title->SetFont(FF_FONT2,FS_BOLD);

// Create a bar pot
$bplot = new BarPlot($tableauNombreProbleme);
$bplot->SetFillColor("purple");
$bplot->SetWidth(0.5);
$bplot->SetShadow();

// Setup the values that are displayed on top of each bar
$bplot->value->Show();
// Must use TTF fonts if we want text at an arbitrary angle
$bplot->value->SetFont(FF_ARIAL,FS_BOLD);
// Black color for positive values and darkred for negative values
$bplot->value->SetColor("black","darkred");
$graph->Add($bplot);

// Finally stroke the graph
$graph->Stroke("auto");
?>
