<?php
	session_start();
	$_SESSION['id_probleme'] = $_POST['id_probleme'];
	print_r($_SESSION);
	header ('location: formIntervention.html');
?>