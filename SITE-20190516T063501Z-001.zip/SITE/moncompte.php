<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
  <link rel="stylesheet" href="theme.css">
</head>

<body>
  	<?php
	  session_start();
    include("connexionbdd.php");

    $type = $_SESSION['type'];
    
    if ($type == "technicien")
    {
      $pseudo_technicien = $_SESSION['pseudo_technicien'];
      $requete = $connexion->query("SELECT * FROM technicien WHERE pseudo_technicien = '$pseudo_technicien'");
      if($requete)
      {
        $donnees = $requete->fetch();
      }

        ?>
        <div class="py-5" style="">
        <div class="container">
          <div class="row">
            <div class="p-5 mx-auto border bg-dark col-lg-12 col-10" style="">
              <h1 class="mb-4 text-center"><?php echo $donnees['nom'] ?> <?php echo $donnees['prenom'] ?></h1>
              <h1 class="mb-4 text-center">Changer de mot de passe:<br></h1>
                <form action = "changermdp.php" method ="post">
                  <div class="form-group">
                    <div class="row">
                      <div class="col-md-12" style="">
                        <div class="form-group row"><label class="col-2" style=""> Ancien Mot de passe: </label>
                          <div class="col-10"><input type="password" class="form-control" id="form14" placeholder="Mot de passe" name="mdp_ancien"></div>
                        </div>
                        <div class="form-group row"><label class="col-2" style=""> Nouveau Mot de passe: </label>
                          <div class="col-10"><input type="password" class="form-control" id="form14" placeholder="Mot de passe" name="mdp_nouveau"></div>
                        </div>
                        <div class="form-group row"><label class="col-2" style=""> Nouveau Mot de passe confirmation: </label>
                          <div class="col-10"><input type="password" class="form-control" id="form14" placeholder="Mot de passe" name="mdp_nouveau_conf"></div>
                        </div>
                        <div class="row">
                          <div class="col-md-12 text-center"><button type="submit" class="btn btn-primary">Envoyer<br></button></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="form-group"> <small class="form-text text-muted text-right"></small> </div>
                </form>
            </div>
          </div>
        </div>
      </div>
  <?php
    }
    else if ($type == "professeur")
    {
      $pseudo_professeur = $_SESSION['pseudo_professeur'];
      $requete = $connexion->query("SELECT * FROM professeur WHERE pseudo_professeur = '$pseudo_professeur'");
      if($requete)
      {
        $donnees = $requete->fetch();
      }
        ?>
        <div class="py-5" style="">
        <div class="container">
          <div class="row">
            <div class="p-5 mx-auto border bg-dark col-lg-12 col-10" style="">
              <h1 class="mb-4 text-center"><?php echo $donnees['nom'] ?> <?php echo $donnees['prenom'] ?></h1>
              <h1 class="mb-4 text-center">Changer de mot de passe:<br></h1>
                <form action = "changermdp.php" method ="post">
                  <div class="form-group">
                    <div class="row">
                      <div class="col-md-12" style="">
                        <div class="form-group row"><label class="col-2" style=""> Ancien Mot de passe: </label>
                          <div class="col-10"><input type="password" class="form-control" id="form14" placeholder="Mot de passe" name="mdp_ancien"></div>
                        </div>
                        <div class="form-group row"><label class="col-2" style=""> Nouveau Mot de passe: </label>
                          <div class="col-10"><input type="password" class="form-control" id="form14" placeholder="Mot de passe" name="mdp_nouveau"></div>
                        </div>
                        <div class="form-group row"><label class="col-2" style=""> Nouveau Mot de passe confirmation: </label>
                          <div class="col-10"><input type="password" class="form-control" id="form14" placeholder="Mot de passe" name="mdp_nouveau_conf"></div>
                        </div>
                        <div class="row">
                          <div class="col-md-12 text-center"><button type="submit" class="btn btn-primary">Envoyer<br></button></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="form-group"> <small class="form-text text-muted text-right"></small> </div>
                </form>
            </div>
          </div>
        </div>
      </div>
      <?php
      }
	    ?>
  

  <nav class="navbar navbar-expand-md navbar-dark bg-primary fixed-top"><a class="navbar-brand" href="#">
      <b> SOS DANTEC</b>
    </a>
    <div class="container-fluid"> <button class="navbar-toggler navbar-toggler-right border-0" type="button" data-toggle="collapse" data-target="#navbar18">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbar18">
      <ul class="navbar-nav ml-5">
          <li class="nav-item text-right ml-5 mr-0"> <a class="nav-link text-white" href="statistique.php">Statistiques<br></a> </li>
        </ul>
        <?php if ($type == "technicien"){ ?>
          <ul class="navbar-nav ml-5">
          <li class="nav-item text-right ml-5 mr-0"> <a class="nav-link text-white" href="inscription.html">Inscrire de nouveaux utilisateurs<br></a> </li>
      </ul>
      <ul class="navbar-nav ml-5">
          <li class="nav-item text-right ml-5 mr-0"> <a class="nav-link text-white" href="voirprobleme.php">Voir les problèmes<br></a> </li>
        </ul>
      <?php
        } else {
        ?>
        <ul class="navbar-nav ml-5">
          <li class="nav-item text-right ml-5 mr-0"> <a class="nav-link text-white" href="formPB.html">Formulaire de dysfonctionnement<br></a> </li>
        </ul>
        <?php
        }
        ?>
        <ul class="navbar-nav ml-5">
          <li class="nav-item text-right ml-5 mr-0"> <a class="nav-link text-white" href="deconnexion.php">Deconnexion<br></a> </li>
        </ul>
      </div>
    </div>
  </nav>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>