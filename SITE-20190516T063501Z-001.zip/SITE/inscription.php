<?php
	include("connexionbdd.php");
	session_start();
	
	// Les valeurs des champs du formulaire
	if (    isset($_POST['nom_professeur']) &&
			isset($_POST['prenom_professeur']) &&
			isset($_POST['pseudo_professeur']) &&
			isset($_POST['mdp_professeur']) &&
			isset($_POST['mdp_conf'])
    ){
    // On les vérifie
    if ($_POST['nom_professeur'] == ""){
        echo '<body onLoad="alert(\'Merci de remplir les champs correctement ! nom\')">';
        echo '<meta http-equiv="refresh" content="0;URL=inscription.html">';
    }
    else if ($_POST['prenom_professeur'] == ""){
        echo '<body onLoad="alert(\'Merci de remplir les champs correctement ! prenom\')">';
        echo '<meta http-equiv="refresh" content="0;URL=inscription.html">';
    }
    else if ($_POST['pseudo_professeur'] == ""){
        echo '<body onLoad="alert(\'Merci de remplir les champs correctement ! pseudo\')">';
        echo '<meta http-equiv="refresh" content="0;URL=inscription.html">';
    }
    else if ($_POST['mdp_professeur'] == ""){
        echo '<body onLoad="alert(\'Merci de remplir les champs correctement ! mot de passe\')">';
        echo '<meta http-equiv="refresh" content="0;URL=inscription.html">';
    }
    else if ($_POST['mdp_conf'] == ""){
    echo '<body onLoad="alert(\'Merci de remplir les champs correctement ! mot de passe conf\')">';
    echo '<meta http-equiv="refresh" content="0;URL=inscription.html">';
    }
    else{
        // Ok, tous les champs sont bons
        //on ajoute les caractères d'échappement devant les caractères spéciaux
        $id_intervention="\N"; //valeur NULL pour id car AUTO_INCREMENT
        $nom_professeur = $connexion->quote($_POST['nom_professeur']);
        $prenom_professeur = $connexion->quote($_POST['prenom_professeur']);
        $pseudo_professeur = $connexion->quote($_POST['pseudo_professeur']);
        $mdp_professeur = $connexion->quote($_POST['mdp_professeur']);
        $mdp_conf = $connexion->quote($_POST['mdp_conf']);
		
		//Vérification que le professeur n'a pas déjà été inscrit dans la bdd
		$req = "SELECT * FROM professeur where pseudo_professeur = $pseudo_professeur";
                 
        $result=$connexion->query($req);
        $donnees = $result->fetch();
        if($donnees['pseudo_professeur']==$_POST['pseudo_professeur']){
            echo '<body onLoad="alert(\'Le professeur est déjà été inscrit !\')">';
			echo '<meta http-equiv="refresh" content="0;URL=inscription.html">';
        }
        //Vérification du mdp
		else if ($mdp_professeur != $mdp_conf)
		{
			echo '<body onLoad="alert(\'Votre mot de passe et votre confirmation sont différents !\')">';
			echo '<meta http-equiv="refresh" content="0;URL=inscription.html">';
						
		}
		else {
				// Creation du membre dans la BDD
				$req="INSERT INTO professeur (nom, prenom, pseudo_professeur, mdp_professeur) 
				VALUES ($nom_professeur,$prenom_professeur,$pseudo_professeur,$mdp_professeur)";
                
				//on utilise exec pour avoir le nombre de ligne insérée, ici on insère 1 ligne
				$nblignes=$connexion->exec($req);
                
                    if($nblignes!=1){
                            $mes_erreur=$connexion->errorInfo();
                            echo "Insertion impossible, code =", $connexion->errorCode().$mes_erreur[2];
                    }
                    else{
                            //$nblignes->closeCursor();
                            echo '<body onLoad="alert(\'Merci, linscription a bien été envoyée !\')">';
							echo '<meta http-equiv="refresh" content="0;URL=inscription.html">';
                    }
                    $connexion=null;
                }
		}
	}
?>
