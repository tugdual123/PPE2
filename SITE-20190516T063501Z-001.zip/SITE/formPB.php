<?php
	include("connexionbdd.php");
	session_start();
	
	$pseudo_professeur = $_SESSION['pseudo_professeur'];
	$requete = $connexion->query("SELECT * FROM professeur WHERE pseudo_professeur = '$pseudo_professeur'");
	if($requete)
	{
		$donnees = $requete->fetch();
	}
    
	// Les valeurs des champs du formulaire
	if (    isset($_POST['Salle']) &&
			isset($_POST['Pc']) &&
			isset($_POST['date']) &&
			isset($_POST['heure']) &&
			isset($_POST['type_probleme'])
    ){
    // On les vérifie
    if ($_POST['Salle'] == ""){
        echo '<body onLoad="alert(\'Merci de remplir les champs correctement ! Salle\')">';
        echo '<meta http-equiv="refresh" content="0;URL=formPB.html">';
    }
    else if ($_POST['Pc'] == ""){
        echo '<body onLoad="alert(\'Merci de remplir les champs correctement ! PC\')">';
        echo '<meta http-equiv="refresh" content="0;URL=formPB.html">';
    }
    else if ($_POST['date'] == ""){
        echo '<body onLoad="alert(\'Merci de remplir les champs correctement ! Date\')">';
        echo '<meta http-equiv="refresh" content="0;URL=formPB.html">';
    }
    else if ($_POST['heure'] == ""){
        echo '<body onLoad="alert(\'Merci de remplir les champs correctement !heure\')">';
        echo '<meta http-equiv="refresh" content="0;URL=formPB.html">';
   }
    else if ($_POST['type_probleme'] == ""){
        echo '<body onLoad="alert(\'Merci de remplir les champs correctement !type de dysfonctionnement\')">';
        echo '<meta http-equiv="refresh" content="0;URL=formPB.html">';
   }
	
    else{
        // Ok, tous les champs sont bons
        //on ajoute les caractères d'échappement devant les caractères spéciaux
        $id_probleme="\N"; //valeur NULL pour id car AUTO_INCREMENT
        $Salle = $connexion->quote($_POST['Salle']);
        $Pc = $connexion->quote($_POST['Pc']);
		$heure = $connexion->quote($_POST['heure']);
        $date = $connexion->quote($_POST['date']);
        $type_probleme = $connexion->quote($_POST['type_probleme']);
        $id_professeur = $donnees['id_professeur'];
		
		
		
                      
                // Creation du membre dans la BDD
				$req="INSERT INTO probleme ( heure, date, type_probleme, id_professeur, id_salle, id_ordinateur) 
				VALUES ($heure,$date,$type_probleme,$id_professeur,$Salle,$Pc)";
                

				//on utilise exec pour avoir le nombre de ligne insérée, ici on insère 1 ligne
				$nblignes=$connexion->exec($req);
                
                    if($nblignes!=1){
                            $mes_erreur=$connexion->errorInfo();
                            echo "Insertion impossible, code =", $connexion->errorCode().$mes_erreur[2];
                    }
                    else{
                           // $result->closeCursor();
                            echo '<body onLoad="alert(\'Merci, votre probleme a bien été signalé !\')">';
							echo '<meta http-equiv="refresh" content="0;URL=formPB.html">';
                    }
                    $connexion=null;
		
	}   }
?>