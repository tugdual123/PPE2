<?php
// ********************************************************************
// PARTIE : Includes et initialisation des variables
// ********************************************************************

// Inclusion de la librairie JpGraph
include ("jpgraph/src/jpgraph.php");
include ("jpgraph/src/jpgraph_pie.php");

// Constantes (connection mysql)
include ("connexionbdd.php");
//define('MYSQL_HOST', 'localhost');
//define('MYSQL_USER', 'root');
//define('MYSQL_PASS', '');
//define('MYSQL_DATABASE', 'tuto_jp_graph');

//supprimé le fichiers "graph1.png" avant d'en créer un nouveau 
unlink("graph1.png");

// Tableaux de données destinées à JpGraph
$tableauTypes = array();
$tableauNombreTypes = array();

// ********************************************************************
// PARTIE : Production des données avec Mysql
// ********************************************************************

header ("Content-type: image/png");
//$sql = <<<EOF
//SELECT COUNT(*) AS NBR, type_probleme AS TYPE
//FROM probleme
//GROUP BY type_probleme

//EOF;

// Connexion à la BDD
//$mysqlCnx = @mysql_connect(MYSQL_HOST, MYSQL_USER, MYSQL_PASS) or die('Pb de connxion mysql');

// Sélection de la base de données
//@mysql_select_db(MYSQL_DATABASE) or die('Pb de sélection de la base');

// Requête
//$mysqlQuery = @mysql_query($sql, $mysqlCnx) or die('Pb de requête');

//requête 
$requete = $connexion->query("SELECT COUNT(*) AS NBR, type_probleme AS TYPE FROM probleme GROUP BY type_probleme");
// Fetch sur chaque enregistrement
while ($row = $requete->fetch()) {
	// Alimentation des tableaux de données
	$tableauTypes[] = $row['TYPE'];
	$tableauNombreTypes[] = $row['NBR'];
}

// ********************************************************************
// PARTIE : Création du graphique 
// ********************************************************************

// On spécifie la largeur et la hauteur du graphique conteneur&#160;
$graph = new PieGraph(1000,600,'auto');

// Titre du graphique
$graph->title->Set("Nombre de dysfonctionnements en fonction des types");
$graph->title->SetFont(FF_FONT2,FS_BOLD);
// Créer un graphique secteur (classe PiePlot)
$oPie = new PiePlot($tableauNombreTypes);

// Légendes qui accompagnent chaque secteur, ici chaque année
$oPie->SetLegends($tableauTypes);

// position du graphique (légèrement à droite)
$oPie->SetCenter(0.4); 

$oPie->SetValueType(PIE_VALUE_ABS);

// Format des valeurs de type entier
$oPie->value->SetFormat('%d');
$oPie->value->SetFont(FF_ARIAL,FS_BOLD);
// Ajouter au graphique le graphique secteur
$graph->Add($oPie);

// Provoquer l'affichage (renvoie directement l'image au navigateur)
$graph->Stroke("auto");
?>