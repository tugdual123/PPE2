<?php
	include("connexionbdd.php");
	session_start();
	
	$pseudo_technicien = $_SESSION['pseudo_technicien'];
	$requete = $connexion->query("SELECT * FROM technicien WHERE pseudo_technicien = '$pseudo_technicien'");
	if($requete)
	{
		$donnees = $requete->fetch();
	}

	print_r($_POST);
	// Les valeurs des champs du formulaire
	if (    isset($_POST['heure_debut']) &&
			isset($_POST['heure_fin']) &&
			isset($_POST['date']) &&
			isset($_POST['typeintervention']) &&
			isset($_POST['cout'])
    ){
    // On les vérifie
    if ($_POST['heure_debut'] == ""){
        echo '<body onLoad="alert(\'Merci de remplir les champs correctement ! Heure de début\')">';
        echo '<meta http-equiv="refresh" content="0;URL=formIntervention.html">';
    }
    else if ($_POST['heure_fin'] == ""){
        echo '<body onLoad="alert(\'Merci de remplir les champs correctement ! Heure de fin\')">';
        echo '<meta http-equiv="refresh" content="0;URL=formIntervention.html">';
    }
    else if ($_POST['date'] == ""){
        echo '<body onLoad="alert(\'Merci de remplir les champs correctement ! Date\')">';
        echo '<meta http-equiv="refresh" content="0;URL=formIntervention.html">';
    }
    else if ($_POST['typeintervention'] == ""){
        echo '<body onLoad="alert(\'Merci de remplir les champs correctement ! Type dintervention\')">';
        echo '<meta http-equiv="refresh" content="0;URL=formIntervention.html">';
   }
   else if ($_POST['cout'] == ""){
        echo '<body onLoad="alert(\'Merci de remplir les champs correctement ! cout\')">';
        echo '<meta http-equiv="refresh" content="0;URL=formIntervention.html">';
   }
    else{
        // Ok, tous les champs sont bons
        //on ajoute les caractères d'échappement devant les caractères spéciaux
        $id_intervention="\N"; //valeur NULL pour id car AUTO_INCREMENT
        $heure_debut = $connexion->quote($_POST['heure_debut']);
        $heure_fin = $connexion->quote($_POST['heure_fin']);
        $date = $connexion->quote($_POST['date']);
        $type_intervention = $connexion->quote($_POST['typeintervention']);
        $cout = $connexion->quote($_POST['cout']);
        $id_technicien = $donnees['id_technicien'];
        $id_probleme = $_SESSION['id_probleme'];
		
		print_r($_SESSION);
		
		//Vérification que l'intervention pour ce probleme n'a pas déjà été inscrite dans la bdd
		$req = "SELECT * FROM intervention where id_probleme = $id_probleme";
                 
        $result=$connexion->query($req);
        $donnees = $result->fetch();
        if($donnees['id_probleme']==$_SESSION['id_probleme']){
            echo '<body onLoad="alert(\'Une intervention à déjà été fait pour ce problème !\')">';
			echo '<meta http-equiv="refresh" content="0;URL=formIntervention.html">';
        }
		else {
                      
                // Creation du membre dans la BDD
				$req="INSERT INTO intervention (id_intervention, heure_debut, heure_fin, date, type_intervention, cout, id_technicien, id_probleme) 
				VALUES ($id_intervention,$heure_debut,$heure_fin,$date,$type_intervention,$cout,$id_technicien,$id_probleme);";
                

				//on utilise exec pour avoir le nombre de ligne insérée, ici on insère 1 ligne
				$nblignes=$connexion->exec($req);
                
                    if($nblignes!=1){
                            $mes_erreur=$connexion->errorInfo();
                            echo "Insertion impossible, code =", $connexion->errorCode().$mes_erreur[2];
                    }
                    else{
                            //$nblignes->closeCursor();
                           

                            echo '<body onLoad="alert(\'Merci, votre intervention a bien été envoyée !\')">';
							echo '<meta http-equiv="refresh" content="0;URL=voirprobleme.php">';
                    }
                    $connexion=null;
                }
		}
	}
?>
