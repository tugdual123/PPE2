<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
  <link rel="stylesheet" href="theme.css">
</head>

<body>
  <nav class="navbar navbar-expand-md navbar-dark my-0 mt-5 mb-0">
    <div class="justify-content-center container"> <button class="navbar-toggler navbar-toggler-right border-0" type="button" data-toggle="collapse" data-target="#navbar3" style="">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse text-center justify-content-center" id="navbar3">
        <ul class="navbar-nav bg-dark text-white" style="">
          <li class="nav-item text-white bg-dark mx-5"> <a class="nav-link" href="voirprobleme.php">Un par un</a> </li>
          <li class="nav-item bg-dark mx-5 text-white" style=""> <a class="nav-link" href="voirproblemeparsalle.php">Par salle<br></a> </li>
        </ul>
      </div>
    </div>
  </nav>
  <?php
	  session_start();
    include("connexionbdd.php");
    $requete1 = $connexion->query("SELECT * FROM salle");
    
    while ($donnee = $requete1->fetch()) {
  ?>
   <div class="py-2" style="">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h1 class="text-center">Salle :
          <?php echo $donnee['nom_salle'] ?>
          </h1>
        </div>
      </div>
      <?php 
      $id_salle = $donnee['id_salle'];
      $requete = $connexion->query("SELECT * FROM probleme,professeur,salle,ordinateur WHERE probleme.id_professeur = professeur.id_professeur AND probleme.id_salle=salle.id_salle AND probleme.id_ordinateur=ordinateur.id_ordinateur AND probleme.id_salle = $id_salle AND id_probleme NOT IN (SELECT intervention.id_probleme FROM intervention,probleme WHERE intervention.id_probleme = probleme.id_probleme) ");
      
      while ($donnees = $requete->fetch()) { ?>
      <div class="row">
        <div class="mx-auto border bg-dark w-100" style="">
          <h4 class="mb-4 text-center">
            <?php echo $donnees['nom'] ?>
            <?php echo $donnees['prenom'] ?>
          </h4>
          <form action="recupprobleme.php" method="post">
            <div class="form-group">
              <div class="row">
                <div class="col-md-6 text-center" style="">
                  <div class="form-group row">
                    <div class="col-md-12">
                      <p class="">Heure :
                        <?php echo $donnees['heure'] ?>
                      </p>
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-md-12">
                      <p>Type de dysfonctionnement :
                        <?php echo $donnees['type_probleme'] ?>
                      </p>
                    </div>
                  </div>
                  <div class="row">
                  </div>
                </div>
                <div class="text-center col-md-6" style="">
                  <div class="form-group row">
                    <div class="col-md-12">
                      <p class="">Poste informatique :
                        <?php echo $donnees['nom_ordinateur'] ?>
                      </p>
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-md-12">
                      <p>Date :
                        <?php echo $donnees['date'] ?>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-12 text-center"><button type="submit" name="id_probleme" value="<?php echo $donnees['id_probleme']?>" class="btn btn-primary">Formulaire d'Intervention<br></button></div>
            </div>
            <div class="form-group"> <small class="form-text text-muted text-right"></small> </div>
          </form>
        </div>
      </div>
      <?php
      } 
      ?>
    </div>
  </div>
  <?php
  } 
  ?>
  <nav class="navbar navbar-expand-md navbar-dark bg-primary fixed-top"><a class="navbar-brand" href="#">
      <b> SOS DANTEC</b>
    </a>
    <div class="container-fluid"> <button class="navbar-toggler navbar-toggler-right border-0" type="button" data-toggle="collapse" data-target="#navbar18">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbar18">
        <ul class="navbar-nav ml-5">
          <li class="nav-item text-right ml-5 mr-0"> <a class="nav-link text-white" href="statistique.php">Statistiques<br></a> </li>
        </ul>
        <ul class="navbar-nav ml-5">
          <li class="nav-item text-right ml-5 mr-0"> <a class="nav-link text-white" href="inscription.html">Inscrire de nouveaux utilisateurs<br></a> </li>
        </ul>
        <ul class="navbar-nav ml-5">
          <li class="nav-item text-right ml-5 mr-0"> <a class="nav-link text-white" href="moncompte.php">Mon Compte<br></a> </li>
        </ul>
        <ul class="navbar-nav ml-5">
          <li class="nav-item text-right ml-5 mr-0"> <a class="nav-link text-white" href="deconnexion.php">Deconnexion<br></a> </li>
        </ul>
      </div>
    </div>
  </nav>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>

</html>
