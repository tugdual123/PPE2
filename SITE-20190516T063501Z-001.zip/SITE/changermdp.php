<?php
	include("connexionbdd.php");
	session_start();
	
	// Les valeurs des champs du formulaire
	if (    isset($_POST['mdp_ancien']) &&
			isset($_POST['mdp_nouveau']) &&
			isset($_POST['mdp_nouveau_conf']) 
    ){
    // On les vérifie
    if ($_POST['mdp_ancien'] == ""){
        echo '<body onLoad="alert(\'Merci de remplir les champs correctement ! mdp ancien\')">';
        echo '<meta http-equiv="refresh" content="0;URL=inscription.html">';
    }
    else if ($_POST['mdp_nouveau'] == ""){
        echo '<body onLoad="alert(\'Merci de remplir les champs correctement ! mdp nouveau\')">';
        echo '<meta http-equiv="refresh" content="0;URL=inscription.html">';
    }
    else if ($_POST['mdp_nouveau_conf'] == ""){
        echo '<body onLoad="alert(\'Merci de remplir les champs correctement ! pseudo\')">';
        echo '<meta http-equiv="refresh" content="0;URL=inscription.html">';
    }
    else{
        // Ok, tous les champs sont bons
        //on ajoute les caractères d'échappement devant les caractères spéciaux
        $mdp_ancien = $connexion->quote($_POST['mdp_ancien']);
        $mdp_nouveau = $connexion->quote($_POST['mdp_nouveau']);
        $mdp_nouveau_conf = $connexion->quote($_POST['mdp_nouveau_conf']);
		
        //Vérification que le professeur n'a pas déjà été inscrit dans la bdd
        $type = $_SESSION['type'];
    
        if ($type == "technicien")
        {
            $pseudo_technicien = $_SESSION['pseudo_technicien'];
            $requete = $connexion->query("SELECT * FROM technicien WHERE pseudo_technicien = '$pseudo_technicien'");
            $donnees = $requete->fetch();

            print_r($donnees);
            echo $donnees['mdp_technicien'];
            echo $mdp_ancien;
            if($donnees['mdp_technicien'] != $_POST['mdp_ancien']){
                //echo '<body onLoad="alert(\'Mauvais ancien mot de passe !\')">';
                //echo '<meta http-equiv="refresh" content="0;URL=moncompte.php">';
            }
            //Vérification du mdp
            else if ($mdp_nouveau != $mdp_nouveau_conf)
            {
                echo '<body onLoad="alert(\'Votre mot de passe et votre confirmation sont différents !\')">';
                echo '<meta http-equiv="refresh" content="0;URL=moncompte.php">';
                            
            }
            else {
                    // Creation du membre dans la BDD
                    $req="UPDATE technicien SET mdp_technicien = $mdp_nouveau WHERE pseudo_technicien = '$pseudo_technicien'";
                    
                    //on utilise exec pour avoir le nombre de ligne insérée, ici on insère 1 ligne
                    $nblignes=$connexion->exec($req);
                    
                        if($nblignes!=1){
                                $mes_erreur=$connexion->errorInfo();
                                echo "Insertion impossible, code =", $connexion->errorCode().$mes_erreur[2];
                        }
                        else{
                                //$nblignes->closeCursor();
                                echo '<body onLoad="alert(\'Merci, le changement de mot de passe a bien été envoyée !\')">';
                                echo '<meta http-equiv="refresh" content="0;URL=moncompte.php">';
                        }
                        $connexion=null;
                    
            }
        }
        else if ($type == "professeur")
        {
          $pseudo_professeur = $_SESSION['pseudo_professeur'];
          $requete = $connexion->query("SELECT * FROM professeur WHERE pseudo_professeur = '$pseudo_professeur'");
          $donnees = $requete->fetch();

          if($donnees['mdp_professeur']!=$_POST['mdp_ancien']){
            echo '<body onLoad="alert(\'Mauvais ancien mot de passe !\')">';
			echo '<meta http-equiv="refresh" content="0;URL=moncompte.php">';
            }
            //Vérification du mdp
            else if ($mdp_nouveau != $mdp_nouveau_conf)
            {
                echo '<body onLoad="alert(\'Votre mot de passe et votre confirmation sont différents !\')">';
                echo '<meta http-equiv="refresh" content="0;URL=moncompte.php">';
                            
            }
            else {
				// Creation du membre dans la BDD
				$req="UPDATE professeur SET mdp_professeur = $mdp_nouveau WHERE pseudo_professeur = '$pseudo_professeur'";
                
				//on utilise exec pour avoir le nombre de ligne insérée, ici on insère 1 ligne
				$nblignes=$connexion->exec($req);
                
                    if($nblignes!=1){
                            $mes_erreur=$connexion->errorInfo();
                            echo "Insertion impossible, code =", $connexion->errorCode().$mes_erreur[2];
                    }
                    else{
                            //$nblignes->closeCursor();
                            echo '<body onLoad="alert(\'Merci, le changement de mot de passe a bien été envoyée !\')">';
							echo '<meta http-equiv="refresh" content="0;URL=moncompte.php">';
                    }
                    $connexion=null;
            }
		}

        }
        
        
	}
?>
