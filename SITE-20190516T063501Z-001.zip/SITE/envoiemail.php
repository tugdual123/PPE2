<?php
if(isset($_POST['mailform']))

$header="MIME-Version: 1.0\r\n";
$header.='From:"pierre"<pierrepierre35150@gmail.com>'."\n";
$header.='Content-Type:text/html; charset="uft-8"'."\n";
$header.='Content-Transfer-Encoding: 8bit';

$message='
<html>
	<body>
		<div align="center">
			<br />
			Vous connaissez BRAVOLOTO?
			Nn cest quoi?
			Une appli gratuit
			<br />
		</div>
	</body>
</html>
';

mail("eline.thivend@gmail.com", "Salut tout le monde !", $message, $header);

?>
<form method="POST" action="">
	<input type="submit" value="Recevoir un mail !" name="mailform"/>
</form>
