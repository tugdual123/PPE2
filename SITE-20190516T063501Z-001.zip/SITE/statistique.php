<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
  <link rel="stylesheet" href="theme.css">
</head>

<body>
  <?php
	  session_start();
    include("connexionbdd.php");

    $type = $_SESSION['type'];
  ?>

  <div class="py-5">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h1 class="text-center"><b>Statistiques et diagrammes</b></h1>
        </div>
      </div>
    </div>
  </div>
  <div class="py-5">
    <div class="container">
      <div class="row">
        <div class="col-md-12"><img class="img-fluid d-block" src="graph1.png"></div>
      </div>
    </div>
  </div>
  <div class="py-5">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
        <?php

        $req1 = $connexion->query("SELECT coutmoyen
        FROM vuecoutmoyen
        ");
        $moy = $req1->fetch()?>
          <h3 class="text-monospace">En moyenne, le coût d'une intervention est de <?php echo $moy['coutmoyen']?>€.</h3>
        </div>
      </div>
    </div>
  </div>
  <div class="py-5" style="">
    <div class="container">
      <div class="row">
        <div class="col-md-12"><img class="img-fluid d-block" src="graph2.png"></div>
      </div>
    </div>
  </div>
  <div class="py-5">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
        <?php

        $req2 = $connexion->query("SELECT COUNT(*) AS NbProblemeMois,  extract(month from date) AS mois
        FROM probleme
        WHERE extract(month from date) = (extract(month from CURDATE()) -1)
        ");
        $nbr = $req2->fetch()?>
          <h3 class="text-monospace">Le mois dernier (0<?php echo $nbr['mois']?>), il y a eu <?php echo $nbr['NbProblemeMois']?> dysfonctionnements de nos ordinateurs.</h3>
        </div>
      </div>
    </div>
  </div>
  <div class="py-5">
    <div class="container">
      <div class="row">
        <div class="col-md-12"><img class="img-fluid d-block" src="graph3.png"></div>
      </div>
    </div>
  </div>
  <nav class="navbar navbar-expand-md navbar-dark bg-primary fixed-top"><a class="navbar-brand" href="#">
      <b> SOS DANTEC</b>
    </a>
    <div class="container-fluid"> <button class="navbar-toggler navbar-toggler-right border-0" type="button" data-toggle="collapse" data-target="#navbar18">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbar18">
        <?php if ($type == "technicien"){ ?>
          <ul class="navbar-nav ml-5">
          <li class="nav-item text-right ml-5 mr-0"> <a class="nav-link text-white" href="inscription.html">Inscrire de nouveaux utilisateurs<br></a> </li>
      </ul>
      <ul class="navbar-nav ml-5">
          <li class="nav-item text-right ml-5 mr-0"> <a class="nav-link text-white" href="voirprobleme.php">Voir les problèmes<br></a> </li>
        </ul>
      <?php
        } else {
        ?>
        <ul class="navbar-nav ml-5">
          <li class="nav-item text-right ml-5 mr-0"> <a class="nav-link text-white" href="formPB.html">Formulaire de dysfonctionnement<br></a> </li>
        </ul>
        <?php
        }
        ?>
        <ul class="navbar-nav ml-5">
          <li class="nav-item text-right ml-5 mr-0"> <a class="nav-link text-white" href="deconnexion.php">Deconnexion<br></a> </li>
        </ul>
      </div>
    </div>
  </nav>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  </body>
</html>